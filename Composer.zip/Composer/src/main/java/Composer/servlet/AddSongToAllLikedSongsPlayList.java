package Composer.servlet;

public class AddSongToAllLikedSongsPlayList {

	public AddSongToAllLikedSongsPlayList() {
		// TODO Auto-generated constructor stub
	}

}
